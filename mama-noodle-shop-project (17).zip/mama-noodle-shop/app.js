const CONFIG = window.APP_CONFIG || { GOOGLE_SCRIPT_URL: "" };
const DEMO_PRODUCTS = [
  {sku:"MN001",name:"บะหมี่รสหมูสับ",description:"รสหมูสับกลมกล่อม อร่อยง่ายในทุกมื้อ",price:10,stock:100,image:"",emoji:"🍜"},
  {sku:"MN002",name:"บะหมี่รสต้มยำกุ้ง",description:"รสต้มยำเข้มข้น เปรี้ยวเผ็ดกำลังดี",price:12,stock:100,image:"",emoji:"🍤"},
  {sku:"MN003",name:"บะหมี่รสต้มยำ",description:"รสจัดจ้าน หอมเครื่องต้มยำ",price:12,stock:80,image:"",emoji:"🌶️"}
];
let products = DEMO_PRODUCTS;
let cart = {};
const $ = id => document.getElementById(id);
const money = n => "฿" + Number(n).toLocaleString("th-TH",{maximumFractionDigits:2});
function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),3000)}
function jsonp(url){
  return new Promise((resolve,reject)=>{
    const cb="mamaJsonp_"+Date.now()+"_"+Math.floor(Math.random()*10000);
    const script=document.createElement("script");
    const timer=setTimeout(()=>{cleanup();reject(new Error("หมดเวลารอข้อมูล"))},10000);
    function cleanup(){delete window[cb];script.remove();clearTimeout(timer)}
    window[cb]=data=>{cleanup();resolve(data)};
    script.onerror=()=>{cleanup();reject(new Error("เชื่อมต่อข้อมูลไม่สำเร็จ"))};
    script.src=url+(url.includes("?")?"&":"?")+"callback="+cb;
    document.body.appendChild(script);
  });
}
async function loadProducts(){
  if(CONFIG.GOOGLE_SCRIPT_URL){
    try{const data=await jsonp(CONFIG.GOOGLE_SCRIPT_URL+"?action=products");if(data.ok&&data.products.length)products=data.products}catch(e){console.warn(e)}
  }
  renderProducts();
}
function renderProducts(){
  $("product-grid").innerHTML=products.map(p=>`
    <article class="product-card">
      <div class="product-visual">${p.image?`<img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}">`:`<span class="product-emoji">${p.emoji||"🍜"}</span>`}</div>
      <div class="product-info"><span class="sku">${escapeHtml(p.sku||"SKU")}</span><h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.description||"บะหมี่กึ่งสำเร็จรูป")}</p>
      <div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-button" data-add="${escapeHtml(p.sku)}">＋ เพิ่มลงตะกร้า</button></div></div>
    </article>`).join("");
  document.querySelectorAll("[data-add]").forEach(b=>b.addEventListener("click",()=>addToCart(b.dataset.add)));
}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function addToCart(sku){const p=products.find(x=>x.sku===sku);if(!p)return;cart[sku]=(cart[sku]||0)+1;updateCart();toast("เพิ่ม "+p.name+" ลงตะกร้าแล้ว")}
function cartRows(){return Object.entries(cart).map(([sku,qty])=>({product:products.find(p=>p.sku===sku),qty})).filter(x=>x.product)}
function total(){return cartRows().reduce((s,x)=>s+Number(x.product.price)*x.qty,0)}
function updateCart(){
  const count=Object.values(cart).reduce((a,b)=>a+b,0);$("cart-count").textContent=count;
  $("cart-items").innerHTML=cartRows().length?cartRows().map(({product:p,qty})=>`<div class="cart-row"><div><b>${escapeHtml(p.name)}</b><br><small>${money(p.price)} / ซอง</small></div><div class="qty-controls"><button data-minus="${p.sku}">−</button><b>${qty}</b><button data-plus="${p.sku}">＋</button></div><button class="remove-button" data-remove="${p.sku}">ลบ</button></div>`).join(""):`<div class="empty-state">🛒<b>ยังไม่มีสินค้าในตะกร้า</b>เลือกสินค้าที่ต้องการจากหน้าร้านได้เลย</div>`;
  $("cart-total").textContent=money(total());$("checkout-total").textContent=money(total());
  document.querySelectorAll("[data-minus]").forEach(b=>b.onclick=()=>{cart[b.dataset.minus]--;if(cart[b.dataset.minus]<=0)delete cart[b.dataset.minus];updateCart()});
  document.querySelectorAll("[data-plus]").forEach(b=>b.onclick=()=>{cart[b.dataset.plus]++;updateCart()});
  document.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{delete cart[b.dataset.remove];updateCart()});
}
function openModal(id){$(id).hidden=false}
function closeModal(id){$(id).hidden=true}
$("open-cart").onclick=()=>{updateCart();openModal("cart-modal")};
$("close-cart").onclick=()=>closeModal("cart-modal");
$("close-checkout").onclick=()=>closeModal("checkout-modal");
$("checkout-button").onclick=()=>{if(!cartRows().length){toast("กรุณาเลือกสินค้าก่อน");return}closeModal("cart-modal");openModal("checkout-modal")};
$("cart-modal").addEventListener("click",e=>{if(e.target.id==="cart-modal")closeModal("cart-modal")});
$("checkout-modal").addEventListener("click",e=>{if(e.target.id==="checkout-modal")closeModal("checkout-modal")});
$("checkout-form").addEventListener("submit",async e=>{
  e.preventDefault();if(!cartRows().length)return;
  const form=new FormData(e.target);
  const order={orderId:"MN"+Date.now(),createdAt:new Date().toISOString(),customer:form.get("customer").trim(),phone:form.get("phone").trim(),address:form.get("address").trim(),note:form.get("note").trim(),items:cartRows().map(x=>({sku:x.product.sku,name:x.product.name,price:Number(x.product.price),qty:x.qty})),total:total(),status:"รอแพ็กสินค้า"};
  if(!order.customer||!order.phone||!order.address){toast("กรุณากรอกข้อมูลให้ครบ");return}
  if(CONFIG.GOOGLE_SCRIPT_URL){
    try{
      await fetch(CONFIG.GOOGLE_SCRIPT_URL,{method:"POST",mode:"no-cors",headers:{"Content-Type":"text/plain;charset=utf-8"},body:JSON.stringify({action:"createOrder",order})});
      toast("ส่งคำสั่งซื้อแล้ว กรุณาตรวจสอบรายการในหน้าผู้ดูแล/Google Sheets");
    }catch(err){toast("ส่งข้อมูลไม่สำเร็จ กรุณาลองใหม่");return}
  }else{
    const saved=JSON.parse(localStorage.getItem("mamaOrders")||"[]");saved.unshift(order);localStorage.setItem("mamaOrders",JSON.stringify(saved));
    toast("บันทึกคำสั่งซื้อในโหมดสาธิตแล้ว");
  }
  cart={};updateCart();e.target.reset();closeModal("checkout-modal");
});
loadProducts();updateCart();
