/*
  ตั้งค่าการเชื่อมต่อ Google Sheets:
  1) Deploy Google Apps Script เป็น Web app
  2) คัดลอก Web app URL (ลงท้ายด้วย /exec)
  3) วาง URL ระหว่างเครื่องหมายอัญประกาศด้านล่าง
  หากยังไม่ใส่ URL เว็บไซต์จะทำงานในโหมดสาธิต โดยเก็บคำสั่งซื้อไว้ในเบราว์เซอร์เครื่องนี้
*/
window.APP_CONFIG = {
  GOOGLE_SCRIPT_URL: ""
};
