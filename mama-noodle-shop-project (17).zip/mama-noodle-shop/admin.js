const CONFIG=window.APP_CONFIG||{GOOGLE_SCRIPT_URL:""};
const $=id=>document.getElementById(id);
const money=n=>"฿"+Number(n).toLocaleString("th-TH",{maximumFractionDigits:2});
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function jsonp(url){return new Promise((resolve,reject)=>{const cb="adminJsonp_"+Date.now();const s=document.createElement("script");const t=setTimeout(()=>{clean();reject(Error("timeout"))},10000);function clean(){delete window[cb];s.remove();clearTimeout(t)}window[cb]=d=>{clean();resolve(d)};s.onerror=()=>{clean();reject(Error("load failed"))};s.src=url+(url.includes("?")?"&":"?")+"callback="+cb;document.body.appendChild(s)})}
async function getOrders(){
  if(CONFIG.GOOGLE_SCRIPT_URL){try{const d=await jsonp(CONFIG.GOOGLE_SCRIPT_URL+"?action=orders");if(d.ok)return d.orders||[]}catch(e){console.warn(e)}}
  return JSON.parse(localStorage.getItem("mamaOrders")||"[]");
}
async function renderOrders(){
  $("orders-list").innerHTML='<div class="loading">กำลังโหลดคำสั่งซื้อ…</div>';
  const orders=await getOrders();
  if(!orders.length){$("orders-list").innerHTML='<div class="empty-state">📦<b>ยังไม่มีคำสั่งซื้อ</b>เมื่อมีลูกค้าสั่งซื้อ รายการจะแสดงที่หน้านี้</div>';return}
  $("orders-list").innerHTML=orders.map(o=>`<article class="order-card" id="order-${esc(o.orderId)}">
    <div class="order-top"><div><h3>คำสั่งซื้อ ${esc(o.orderId)}</h3><div class="order-meta">${new Date(o.createdAt).toLocaleString("th-TH")}</div></div><strong>${money(o.total)}</strong></div>
    <div class="order-address"><b>ผู้รับ:</b> ${esc(o.customer)}　<b>โทร:</b> ${esc(o.phone)}<br><b>ที่อยู่:</b> ${esc(o.address)}<br>${o.note?`<b>หมายเหตุ:</b> ${esc(o.note)}`:""}</div>
    <div class="order-items"><b>รายการสินค้า</b><br>${(o.items||[]).map(i=>`${esc(i.name)} (${esc(i.sku)}) × ${i.qty} = ${money(i.price*i.qty)}`).join("<br>")}</div>
    <div class="order-actions"><label>สถานะ <select class="status-select" data-status="${esc(o.orderId)}"><option ${o.status==="รอแพ็กสินค้า"?"selected":""}>รอแพ็กสินค้า</option><option ${o.status==="กำลังจัดส่ง"?"selected":""}>กำลังจัดส่ง</option><option ${o.status==="จัดส่งแล้ว"?"selected":""}>จัดส่งแล้ว</option></select></label><button class="outline-button" data-print="${esc(o.orderId)}">🖨 พิมพ์ใบแพ็ก/จ่าหน้า</button></div>
  </article>`).join("");
  document.querySelectorAll("[data-print]").forEach(b=>b.onclick=()=>{document.querySelectorAll(".order-card").forEach(c=>c.classList.remove("print-target"));$("order-"+CSS.escape(b.dataset.print)).classList.add("print-target");window.print()});
  document.querySelectorAll("[data-status]").forEach(s=>s.onchange=()=>updateStatus(s.dataset.status,s.value));
}
async function updateStatus(id,status){
  if(CONFIG.GOOGLE_SCRIPT_URL){alert("การเปลี่ยนสถานะในเวอร์ชันเชื่อม Google Sheets ให้แก้คอลัมน์ Status ในชีต Orders โดยตรงในรุ่นนี้ค่ะ");return}
  const list=JSON.parse(localStorage.getItem("mamaOrders")||"[]");const o=list.find(x=>x.orderId===id);if(o){o.status=status;localStorage.setItem("mamaOrders",JSON.stringify(list))}
}
$("refresh-orders").onclick=renderOrders;renderOrders();
